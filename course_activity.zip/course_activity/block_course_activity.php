<?php


class block_course_activity extends block_base {

    public function init() {
       $this->title = 'Course Activity';
    }

    public function get_content() {
        global $CFG, $USER, $COURSE,$DB;
		if ($this->content !== null) {
            return $this->content;
        }

$params=array();
$params['id']=$COURSE->id;
$course = $DB->get_record('course', $params, '*', MUST_EXIST);

 $modinfo = get_fast_modinfo($course);
    $modnames = get_module_types_names();
    $modnamesplural = get_module_types_names(true);
    $modnamesused = $modinfo->get_used_module_names();
    $mods = $modinfo->get_cms();
    //$modinfosections = $modinfo->get_section_info_all();
$sections=$modinfo->get_section_info_all();

foreach ($sections as $key => $section) {

}

  $modinfosections = $modinfo->get_sections();
  $this->content = new stdClass;
 $this->content->text = '';

 if(!empty($modinfosections[$section->section]))
{
foreach ($modinfosections[$section->section] as $cmid) {
                        $cm = $modinfo->cms[$cmid];
               
if(!empty($cm))
{
$filePath=$cm->url;
$filePaths=$filePath->get_scheme();
              
$moduleId=$cm->id;                     //echo "cmid=".$cm;
$fileName=$cm->name;

if($cm->completion == 0)
{
$completionStatus="Not Completed";
}
else
{
   $completionStatus="Completed"; 
}

$timeCreated=date('Y-m-d',$cm->added);
 $this->content->text .= html_writer::link(new moodle_url($filePath), $moduleId." ".$fileName." ".$timeCreated." ".$completionStatus) . '<br>';

}
                    }
                }
                else
                {
$this->content->text .="No Activity";
                }
      
        return $this->content;
    }

    public function has_config() {
        return true;
    }

    public function applicable_formats() {
        return array('all' => true);
    }

    public function instance_allow_config() {
        return true;
    }

}
