<?php

//plugin name
$string['pluginname'] = 'Course Activity';

