<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2017060701;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2010112400;        // Requires this Moodle version      
$plugin->component = 'block_course_activity';
